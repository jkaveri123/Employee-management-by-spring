package com.jsp.Employee_management.clone;

import lombok.Data;

@Data
public class EmployeeClone {
	private String name;
	private String Mname;
	private String Lname;
	private String email;
	private String pwd;
	

}
