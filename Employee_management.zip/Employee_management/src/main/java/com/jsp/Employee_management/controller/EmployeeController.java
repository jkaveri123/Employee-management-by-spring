package com.jsp.Employee_management.controller;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.Employee_management.Entity.EmployeeDetails;
import com.jsp.Employee_management.clone.EmployeeClone;
import com.jsp.Employee_management.service.EmployeeService;
import com.jsp.Employee_management.util.ResponseStructure;


@RestController
public class EmployeeController {
	@Autowired
	EmployeeService service;
	@Autowired
	ModelMapper mapper;

	@PostMapping("/save")

	public EmployeeClone register(@RequestBody EmployeeDetails e) {
		EmployeeDetails register = service.SaveEmployee(e);
		try {
			EmployeeClone ec = m1(register);
			return ec;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;

	}

	@PostMapping("/emp")
	private EmployeeClone m1(@RequestBody EmployeeDetails emp) {
		EmployeeClone c = mapper.map(emp, EmployeeClone.class);
		return c;
	}

	@PostMapping("/sendhtml")
	public String sendHtml(@RequestBody EmployeeDetails emp) {
		try {
			service.sendHtmlEmail(emp);
			return "msg send successfully";
		} catch (Exception e) {
			return "internal error";
		}
	}

	@GetMapping("/find")
	public ResponseEntity<ResponseStructure<EmployeeDetails>> findById(@RequestParam int id) {
		return service.fetchEmployeeDetails(id);
	}

	@DeleteMapping("/delete")
	public ResponseEntity<ResponseStructure<EmployeeDetails>> delete(@RequestParam int id) {
		return service.delete(id);
	}
//	@PutMapping("/update")
//    public ResponseEntity<EmployeeClone> update(@RequestBody EmployeeDetails employeeDetails) {
//        try {
//            ResponseEntity<ResponseStructure<EmployeeDetails>> updatedEmployee = service.updateEmployee(employeeDetails);
//            EmployeeClone employeeClone = convertToClone(updatedEmployee);
//            return new ResponseEntity<>(employeeClone, HttpStatus.OK);
//        } catch (Exception e) {
//            e.printStackTrace();
//            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }
//
//	private EmployeeClone convertToClone(ResponseEntity<ResponseStructure<EmployeeDetails>> updatedEmployee) {
//		EmployeeClone c = mapper.map(updatedEmployee, EmployeeClone.class);
//		return c;
//	}
}
