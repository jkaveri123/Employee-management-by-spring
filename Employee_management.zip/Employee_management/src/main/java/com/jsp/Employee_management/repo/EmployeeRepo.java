package com.jsp.Employee_management.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.jsp.Employee_management.Entity.EmployeeDetails;


public interface EmployeeRepo extends JpaRepository<EmployeeDetails, Integer> {
	@Query("delete from EmployeeDetails where email=?1")
	EmployeeDetails deleteByEmail(String email);
}
